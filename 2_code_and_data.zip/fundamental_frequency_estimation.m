function ff = fundamental_frequency_estimation(d_,fs,params)

% See (Ng and Goldberger, 2007) and (Barquero-P�rez et al., 2012) for algorithm details


fn = fs/2;

% high pass filter
[b1,a1] = butter(5,params.fl1/fn,'high');

% rectification
y=filtfilt(b1,a1,d_);
yabs = abs((y));

% low pass filter
[b2,a2] = butter(5,params.fh2/fn,'low');
z = filtfilt(b2,a2,detrend((yabs)));

z = detrend(z);
[P,f] = spectral_estimation(z,fs,params);
    
% search the fundamental frequency
ind_search = f>=0.3 & f<=1.5;
P(~ind_search) = 0;
[~, indff]=max(P);

ff = f(indff);
