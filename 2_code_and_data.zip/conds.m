     

% interpolation frequency
f_interp = 50;                  % Hz

% parameters for the PSD computation
params.L = 512;            % window for the pwelch
params.nfft = 2048;     	% nfft points for pwelch
params.noverlap = [];      % noverlap for pwelch


% parameters for the f0 estimation
params.fl1 = 20;        % Hz - cut frequency for the high-pass filter.
params.fh2=1.5;         % Hz - cut frequency for the low-pass filter.

% parameters for the ri calculation
params.bil = 0.3;       % Hz - lower bound for the band of interest
params.bih = 15;        % Hz - higher bound for the band of interest
params.riw = 1;   

% parameters for LPC calculation
M = 2^12;

