function d_psd = compPSD(d_, params, f_interp)

% substract mean and divide by variance
% [pxx,f] = pwelch(x,window,noverlap,nfft,fs) --> d_psdAll


window = params.L;
noverlap = params.noverlap;
nfft = params.nfft;


% get data
t = d_(:,1);
x = d_(:,2);
y = d_(:,3);
z = d_(:,4);

% remove mean and divide by sd
x = (x-mean(x))./ std(x);
y = (y-mean(y))./ std(y);
z = (z-mean(z))./ std(z);

% calculate PSD
% x
[psd_x, psd_f] = pwelch(x,window,noverlap,nfft,f_interp);

% y
[psd_y, ~] = pwelch(y,window,noverlap,nfft,f_interp);

% z
[psd_z, ~] = pwelch(z,window,noverlap,nfft,f_interp);

% area 1
psd_x = psd_x ./ sum(psd_x);
psd_y = psd_y ./ sum(psd_y);
psd_z = psd_z ./ sum(psd_z);

d_psd(:,1) = psd_f;
d_psd(:,2) = psd_x;
d_psd(:,3) = psd_y;
d_psd(:,4) = psd_z;