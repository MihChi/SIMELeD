close all; clear all; clc

conds       % import parameters

load('data.mat')

%% interpolate data to have the exact same time stamps
for i = 1:length(p)
    p(i).rh.accInterp = interpData(p(i).rh.accOrig, f_interp);      p(i).rh.f_interp = f_interp;
    p(i).lh.accInterp = interpData(p(i).lh.accOrig, f_interp);      p(i).lh.f_interp = f_interp;
    p(i).ra.accInterp = interpData(p(i).ra.accOrig, f_interp);      p(i).ra.f_interp = f_interp;
    p(i).la.accInterp = interpData(p(i).la.accOrig, f_interp);      p(i).la.f_interp = f_interp;
end


%% plot all signals 
for i = 1:length(p)
figure;
    ax1 = subplot(221);
        plot(p(i).lh.accInterp(:,1), p(i).lh.accInterp(:,2), 'k-', p(i).lh.accInterp(:,1), p(i).lh.accInterp(:,3), 'b-', p(i).lh.accInterp(:,1), p(i).lh.accInterp(:,4), 'r-');
        legend('V', 'AP', 'ML')
        title('Left hip'); ylabel('Aceleration (g)'); xlabel('Time (s)')
    ax2 = subplot(222);
        plot(p(i).rh.accInterp(:,1), p(i).rh.accInterp(:,2), 'k-', p(i).rh.accInterp(:,1), p(i).rh.accInterp(:,3), 'b-', p(i).rh.accInterp(:,1), p(i).rh.accInterp(:,4), 'r-');
        title('Right hip'); ylabel('Aceleration (g)'); xlabel('Time (s)')
    ax3 = subplot(223);
        plot(p(i).la.accInterp(:,1), p(i).la.accInterp(:,2), 'k-', p(i).la.accInterp(:,1), p(i).la.accInterp(:,3), 'b-', p(i).la.accInterp(:,1), p(i).la.accInterp(:,4), 'r-');
        title('Left Ankle'); ylabel('Aceleration (g)'); xlabel('Time (s)')
    ax4 = subplot(224);
        plot(p(i).ra.accInterp(:,1), p(i).ra.accInterp(:,2), 'k-', p(i).ra.accInterp(:,1), p(i).ra.accInterp(:,3), 'b-', p(i).ra.accInterp(:,1), p(i).ra.accInterp(:,4), 'r-');
        title('Right Ankle'); ylabel('Aceleration (g)'); xlabel('Time (s)')

    linkaxes([ax1,ax2,ax3,ax4],'xy')
    xlim([1 6]); ylim([-8 8])
end
%% calculate PSD

for i = 1:length(p)
    p(i).rh.psd = compPSD(p(i).rh.accInterp, params, f_interp);  
    p(i).lh.psd = compPSD(p(i).lh.accInterp, params, f_interp);  
    p(i).ra.psd = compPSD(p(i).ra.accInterp, params, f_interp);  
    p(i).la.psd = compPSD(p(i).la.accInterp, params, f_interp);  
end

%% plot PSD for one aceleration signal
figure;
subplot(121);
    plot(p(1).rh.accInterp(:,1), p(1).rh.accInterp(:,2), 'k-');
    ylabel('Aceleration (g)'); xlabel('Time (s)')
    xlim([1 7]); ylim([0 4])
subplot(122);
    plot(p(1).rh.psd(:,1), p(1).rh.psd(:,2), 'k-');
    ylabel('PSD (a.u.)'); xlabel('Frequency (Hz)')
    xlim([0 25]); 
    
%% f_0, f_d, r_i  (only for right hip and one patient. similar for other locations)
disp('    V         AP        ML')
disp('RIGHT HIP')


% dominant frequency for right hip
[~, I] = sort(p(1).rh.psd(:,2), 'descend');      p(1).rh.fa.fdom(:,2) = p(1).rh.psd(I(find(p(1).rh.psd(I,1)>=0.3,1)),1);  
[~, I] = sort(p(1).rh.psd(:,3), 'descend');      p(1).rh.fa.fdom(:,3) = p(1).rh.psd(I(find(p(1).rh.psd(I,1)>=0.3,1)),1);  
[~, I] = sort(p(1).rh.psd(:,4), 'descend');      p(1).rh.fa.fdom(:,4) = p(1).rh.psd(I(find(p(1).rh.psd(I,1)>=0.3,1)),1);  

disp('dominant frequency:')
disp(p(1).rh.fa.fdom(2:4));

% fundamental frequency for right hip
p(1).rh.fa.f0(:,2) = fundamental_frequency_estimation(p(1).rh.accInterp(:,2),p(1).rh.f_interp,params);
p(1).rh.fa.f0(:,3) = fundamental_frequency_estimation(p(1).rh.accInterp(:,3),p(1).rh.f_interp,params);
p(1).rh.fa.f0(:,4) = fundamental_frequency_estimation(p(1).rh.accInterp(:,4),p(1).rh.f_interp,params);

disp('fundamental frequency:')
disp(p(1).rh.fa.f0(2:4));

% regularity index
% CD        
p(1).rh.fa.ri(:,2)=regularity_index(p(1).rh.psd(:,2),p(1).rh.psd(:,1),p(1).rh.fa.fdom(:,2),params);
p(1).rh.fa.ri(:,3)=regularity_index(p(1).rh.psd(:,3),p(1).rh.psd(:,1),p(1).rh.fa.fdom(:,3),params);
p(1).rh.fa.ri(:,4)=regularity_index(p(1).rh.psd(:,4),p(1).rh.psd(:,1),p(1).rh.fa.fdom(:,4),params);

disp('regularity index:')
disp(p(1).rh.fa.ri(2:4));

%% spectral envelope estimated with LPC  (only for right hip. similar for other locations)
[p(1).rh.lpc,p(1).rh.lpc_E] = spectral_envelope(p(1).rh.accInterp); 

% plot estimated envelope vs PSD (for V axis)
figure; hold on
plot(p(1).rh.psd(:,1), p(1).rh.psd(:,2)./max(p(1).rh.psd(:,2)));
[En,ff]= freqz(p(1).rh.lpc_E(:,2),p(1).rh.lpc(:,2),M,f_interp);     
plot(ff,abs(En)/max(abs(En)),'k')
title('Comparison between PSD and estimated envelope. right hip, V axis')
xlabel('Hz'); ylabel('|FFT|')