function d_interp = interpData(d_orig, freq)

t_orig = d_orig(:,1);

d_interp(:,1) = [round(t_orig(1))+1:1/freq:round(t_orig(end))-1]';

% lineal interpolation
d_interp(:,2) = interp1(t_orig,d_orig(:,2),d_interp(:,1));  
d_interp(:,3) = interp1(t_orig,d_orig(:,3),d_interp(:,1));  
d_interp(:,4) = interp1(t_orig,d_orig(:,4),d_interp(:,1));   