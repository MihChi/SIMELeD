function [lpc_,E_lpc] = spectral_envelope(d_)
%LPC order
p=20;
% get data
t = d_(:,1);
x = d_(:,2)- mean(d_(:,2));
y = d_(:,3)- mean(d_(:,3));
z = d_(:,4)- mean(d_(:,4));

%LPC x
lpc_x = lpc(x,p);
E_x = sqrt(sum(x.^2));

%LPC y
lpc_y = lpc(y,p);
E_y = sqrt(sum(y.^2));

%LPC z
lpc_z = lpc(z,p);
E_z = sqrt(sum(z.^2));


% save result
lpc_(:,2) = lpc_x;
lpc_(:,3) = lpc_y;
lpc_(:,4) = lpc_z;
E_lpc(:,2) = E_x;
E_lpc(:,3) = E_y;
E_lpc(:,4) = E_z;
