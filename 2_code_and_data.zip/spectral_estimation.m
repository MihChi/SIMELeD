function [P,f] = spectral_estimation(d_,fs,params)

window = params.L;
noverlap = params.noverlap;
nfft = params.nfft;

[P,f] = pwelch(d_-mean(d_),feval('hanning',window),noverlap,nfft,fs);

P = P/max(P);
