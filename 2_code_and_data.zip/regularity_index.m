function ri = regularity_index(d_,f,fdom,params)

rad=params.riw/2;
ew=0;

[~,ini] = min(abs(f-(fdom-rad)));
[~,fin] = min(abs(f-(fdom+rad)));
ew=sum(d_(ini:fin))+ew;

[~,ini] = min(abs(f-params.bil));
[~,fin] = min(abs(f-params.bih));

ri=ew/sum(d_(ini:fin));