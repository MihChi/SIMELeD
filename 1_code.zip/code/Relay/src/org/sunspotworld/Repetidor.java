package org.sunspotworld;
/**
 *
 * @author mihaela.chidean@urjc.es
 */

import com.sun.spot.peripheral.Spot;
import com.sun.spot.peripheral.radio.IRadioPolicyManager;
import com.sun.spot.resources.Resources;
import com.sun.spot.resources.transducers.ITriColorLED;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;


public class Repetidor extends MIDlet implements Constants, Constants_Tipo{

    protected void startApp() throws MIDletStateChangeException {
        
        // Set transmission properties
        IRadioPolicyManager rpm = Spot.getInstance().getRadioPolicyManager();

        if (TIPO_APP.equalsIgnoreCase(TIPO_C)) {
            rpm.setChannelNumber(SPOT_CHANNEL_C);
            rpm.setPanId(SPOT_PANID_C); 
        } else {
            rpm.setChannelNumber(SPOT_CHANNEL_P);
            rpm.setPanId(SPOT_PANID_P);
        }
        rpm.setOutputPower(SPOT_POWER);
        System.out.println("channel: " + rpm.getChannelNumber());
        System.out.println("PAN: " + rpm.getPanId());
        System.out.println("power: " + rpm.getOutputPower());
        

        while(true){
            
        }
    }

    protected void pauseApp() {
        // This is not currently called by the Squawk VM
    }

    /**
     * Called if the MIDlet is terminated by the system.
     * It is not called if MIDlet.notifyDestroyed() was called.
     *
     * @param unconditional If true the MIDlet must cleanup and release all resources.
     */
    protected void destroyApp(boolean unconditional) throws MIDletStateChangeException {
    }
}
