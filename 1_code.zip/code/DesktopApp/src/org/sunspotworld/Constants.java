package org.sunspotworld;
/**
 *
 * @author mihaela.chidean@urjc.es
 */


public interface Constants {
    
    /** Broadcast port on which we listen for sensor samples. */
    public static final String HOST_PORT = "67";
    /** Port to use for sending commands and replies between the SPOT and the host application. */
    public static final String BROADCAST_PORT = "43";
    
    /** Channel used by the SPOTS. */
    public static final int SPOT_CHANNEL_C = 11;  // [11, 26]
    public static final int SPOT_CHANNEL_P = 25;  // [11, 26]

    /** PAN ID used by the SPOTS. */
    public static final short SPOT_PANID_C = 3;  
    public static final short SPOT_PANID_P = 4; 
    /** Power used By the SPOTS. */
    public static final int SPOT_POWER = 0;    // [-32, 0], salvo en channel 26 donde el m�ximo es -3
    
    public static final int SAMPLE_PERIOD = 20;  // in milliseconds
        
    public static final int NUM_MEASURES = 3;
    public static final int TAM_PAQUETE = 20;
    
    /** Flags used in the trace file. */
    public static final String flagFile = "-f ";
    public static final String flags[] = {"-t ", "-s ", "-aX ", "-aY ", "-aZ ", "-tX ", "-tY ", "-tZ "};
    public static final String flagPrueba = "-p ";
    public static final String flagFin = "-x ";
    public static final String flagsDoc[] = {"-d ", "-dd "};
    public static final String flagCalib = "-c ";
    public static final String flagBat = "-b ";
    public static final String flag_RSSI = "-q ";
    
    /** Menu constants. */
    public static final String NEW_FLOW_TEXT = "Start experiment";   
    public static final String EXIT_TEXT = "Exit";
    public static final String EXIT_FLOW_TEXT = "Finish experiment";
    
    
    // comboBox
    public static final String SELECCIONA = "---Choose option---";
    public static final String DOCUM = "Documentation";
    public static final String PRUEBA1 = "Walk";
    public static final String PRUEBA2 = "Self-paced run";
    public static final String PRUEBA3 = "Run (10-12 Km/h)";
    
    public static final int SELECCIONA_INDEX = 0;
    public static final int DOCUM_INDEX = 1;
    public static final int PRUEBA1_INDEX = 2;
    public static final int PRUEBA2_INDEX = 3;
    public static final int PRUEBA3_INDEX = 4; 
    
    
    // textos informativos
    public static final String INFO_TEXT_SELEC = "Choose one of the possible options";
    public static final String INFO_TEXT_DOCU = "Write the documentation and press Accept";
    public static final String INFO_TEXT_PR1 = "Flag the start point by pressing Accept";
    public static final String INFO_TEXT_PR2 = "Flag the start point by pressing Accept";
    public static final String INFO_TEXT_PR3 = "PFlag the start point by pressing Accept";
    public static final String INFO_TEXT_KO = "ComboBox ko";
    public static final String INFO_TEXT_INI = "Press Start Experiment";
    public static final String INFO_TEXT_DOC_OK = "Documentation stored";
    public static final String INFO_TEXT_NO_DOC = "With this option you have to write inside the box";
    
    public static final String INFO_TEXT_TIPO_C = "Data gathering from hip SunSPOTs";
    public static final String INFO_TEXT_TIPO_P = "Data gathering from ankle SunSPOTs";
    
    /** Server command to indicate the start of the data flow. */
    public static final byte START_DATA_FLOW = 1;
    /** Server command to indicate the stop of the data flow. */
    public static final byte STOP_DATA_FLOW = 2;
    /** Host command to indicate it is quitting. */
    public static final byte DISPLAY_SERVER_QUITTING    = 3;    // (direct p2p)


}