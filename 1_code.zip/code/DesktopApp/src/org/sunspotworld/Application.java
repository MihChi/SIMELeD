package org.sunspotworld;

/**
 *
 * @author mihaela.chidean@urjc.es
 */

import com.sun.spot.io.j2me.radiogram.Radiogram;
import com.sun.spot.io.j2me.radiogram.RadiogramConnection;
import com.sun.spot.peripheral.ota.OTACommandServer;
import com.sun.spot.peripheral.radio.IRadioPolicyManager;
import com.sun.spot.peripheral.radio.RadioFactory;
import com.sun.spot.util.Utils;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.microedition.io.Connector;
import javax.microedition.io.Datagram;
import javax.microedition.io.DatagramConnection;

public class Application implements Constants, Constants_Tipo {

    private static BufferedWriter bw;
    private static Boolean testOnCourse;
    private static final Object lockTestOnCourse = new Object();
    private static String oldDoc = "";
    private static int oldType = -1;
    private static Boolean calibOK = false;
    private static GUI_Frame frame;
    // Rx connection
    private static RadiogramConnection rCon;
    private static Datagram dg;
    // Tx connection
    private static DatagramConnection txConn;
    private static Datagram txDg;

    private void run() throws Exception {

        DateFormat fmt = DateFormat.getTimeInstance();

        IRadioPolicyManager rpm = RadioFactory.getRadioPolicyManager();
        if (TIPO_APP.equalsIgnoreCase(TIPO_C)){
            rpm.setChannelNumber(SPOT_CHANNEL_C);
            rpm.setPanId(SPOT_PANID_C);
        } else {
            rpm.setChannelNumber(SPOT_CHANNEL_P);
            rpm.setPanId(SPOT_PANID_P);
        }
        
        rpm.setOutputPower(SPOT_POWER);

        System.out.println("channel: " + rpm.getChannelNumber());
        System.out.println("PAN: " + rpm.getPanId());
        System.out.println("power: " + rpm.getOutputPower());

        try {
            // data Rx connection
            rCon = (RadiogramConnection) Connector.open("radiogram://:" + HOST_PORT);
            dg = rCon.newDatagram(rCon.getMaximumLength());

            // broadcast Tx connection
            txConn = (DatagramConnection) Connector.open("radiogram://broadcast:" + BROADCAST_PORT);
            ((RadiogramConnection) txConn).setMaxBroadcastHops(4);
            txDg = txConn.newDatagram(txConn.getMaximumLength());

        } catch (Exception e) {
            System.err.println("setUp caught " + e.getMessage());
            throw e;
        }


        // Main data collection loop
        while (true) {
            try {
                // Read sensor sample received over the radio
                rCon.receive(dg);
                int q = ((Radiogram) dg).getRssi();
                String addr = dg.getAddress();              // read sender's Id
                int max_tx = (dg.getLength()/TAM_PAQUETE);
                

                for (int k = 0; k < max_tx; k++) {
                    long time = dg.readLong();              // timestamp
                    float[] reading = new float[NUM_MEASURES];
                    for (int i = 0; i < reading.length; i++) {
                        reading[i] = dg.readFloat();        // acceleration data
                    }

                    // write in the file
                    String line = constructLine(time, addr, reading, q);


                    synchronized (lockTestOnCourse) {
                        if (testOnCourse) {

                            bw.write(line);
                            bw.flush();

                        }
                    }
                }
            } catch (Exception e) {
                System.err.println("Caught " + e + " while reading sensor samples.");
                throw e;
            }
        }
    }

    /**
     * Start up the host application.
     *
     * @param args any command line arguments
     */
    public static void main(String[] args) throws Exception {
        // register the application's name with the OTA Command server & start OTA running
        OTACommandServer.start("SendData");

        frame = new GUI_Frame();

        synchronized (lockTestOnCourse) {
            testOnCourse = false;
        }

        Application app = new Application();
        app.run();
        System.exit(0);

    }

    public static String createFilename() {
        Date now = new Date();

        SimpleDateFormat formateador = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");

        return "Acc_Data_" + formateador.format(now) + "_" + TIPO_APP + ".txt";
    }

    private static void createFile(String fn) {
        File fichero = new File(fn);
    }

    private static void createFileHeader(BufferedWriter bw, String fn) {
        synchronized (lockTestOnCourse) {
            try {
                bw.write(flagFile + "Fichero: " + fn + "\r\n");
                bw.flush();
            } catch (IOException ex) {
                Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    private String constructLine(long time, String addr, float[] reading, int q) {
        String line = "";
        SimpleDateFormat formateador = new SimpleDateFormat("HH:mm:ss.SSS");
        line = line + flags[0] + formateador.format(new Date(time)) + " ";
        line = line + flags[1] + addr + " ";
        for (int i = 0; i < reading.length; i++) {
            line = line + flags[i + 2] + reading[i] + " ";
        }
        line = line + flag_RSSI + q;
        line = line + "\r\n";

        return line;
    }

    private String constructLine(long time, String addr, int reading, int q) {

        String line = "";
        SimpleDateFormat formateador = new SimpleDateFormat("HH:mm:ss.SSSSS");
        line = line + flags[0] + formateador.format(new Date(time)) + " ";
        line = line + flags[1] + addr + " ";
        line = line + flagBat + reading + " ";
        line = line + flag_RSSI + q;

        line = line + "\r\n";

        return line;
    }

    /**
     * Set up everything to store tha acceleration data into a text file.
     *
     */
    public void prepareNewFlow() {

        String filename = createFilename();
        createFile(filename);
        try {
            bw = new BufferedWriter(new FileWriter(filename));
            createFileHeader(bw, filename);
        } catch (IOException ex) {
            System.out.println(ex);
            Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Application: Data Flow prepared!!!!");
    }

    /**
     * Flag the test starting point with the test type. 
     * @param Test type as in Constants.java
     */
    public void startNewFlow(int tipo) {
        System.out.println("Application: Message to SPOT to start transmission");
        broadcastCmd(START_DATA_FLOW);

        oldType = tipo;
        String info = "";
        switch (tipo) {
            case PRUEBA1_INDEX:
                info = PRUEBA1;
                break;
            case PRUEBA2_INDEX:
                info = PRUEBA2;
                break;
            case PRUEBA3_INDEX:
                info = PRUEBA3;
                break;
        }
        synchronized (lockTestOnCourse) {
            try {
                bw.write(flagPrueba + info + "\r\n");
                bw.flush();
                testOnCourse = true;
            } catch (IOException ex) {
                Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        frame.disableDocum();
    }

    /**
     * Flag the test stop point.
     *
     */
    public void stopFlow() {
        broadcastCmd(STOP_DATA_FLOW);
        System.out.println("Application: Message to SPOT to stop transmission");
        Utils.sleep(10000);
        synchronized (lockTestOnCourse) {
            testOnCourse = false;
            oldType = -1;
            try {
                SimpleDateFormat formateador = new SimpleDateFormat("HH:mm:ss");
                bw.write(flagFin + "Test finised at " + formateador.format(new Date()));
                System.out.println("Application: Test finished");
                bw.flush();
                bw.close();    
            } catch (IOException ex) {
                Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * Flag the documentation. First line with -d flag, next lines with -dd flag.
     * @param texto String de una o varias lineas a incluir en el fichero
     */
    public boolean addDocumentation(String texto) {
        if (texto.equals(oldDoc)) {
            return false;
        }
        synchronized (lockTestOnCourse) {
            if (!testOnCourse) {
                try {
                    String[] lines = texto.split("\r\n|\r|\n");
                    bw.write(flagsDoc[0] + lines[0] + "\r\n");
                    for (int i = 1; i < lines.length; i++) {
                        bw.write(flagsDoc[1] + lines[i] + "\r\n");
                    }
                    bw.flush();
                } catch (IOException ex) {
                    Logger.getLogger(Application.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                return false;
            }
        }
        oldDoc = texto;
        return true;
    }

    private static void broadcastCmd(byte cmd) {
        try {
            txDg.reset();
            txDg.writeByte(cmd);
            txConn.send(txDg);
        } catch (IOException ex) {
            System.out.println("Error broadcasting server start/quit command: " + ex.toString());
        }

    }

    void doQuit() {
        broadcastCmd(DISPLAY_SERVER_QUITTING);
        Utils.sleep(10);
        System.exit(0);
    }
}
