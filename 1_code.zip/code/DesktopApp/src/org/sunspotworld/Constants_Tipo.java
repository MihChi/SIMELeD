package org.sunspotworld;

/**
 *
 * @author mihaela.chidean@urjc.es
 */
interface Constants_Tipo {
    
    
    public static final String TIPO_APP = "P";     // C=Hip; P=Ankle
    public static final String TIPO_C = "C";
    public static final String TIPO_P = "P";
    
    
}
