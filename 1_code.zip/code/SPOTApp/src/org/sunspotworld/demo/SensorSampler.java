package org.sunspotworld.demo;
/**
 *
 * @author mihaela.chidean@urjc.es
 */


import com.sun.spot.io.j2me.radiogram.RadiogramConnection;
import com.sun.spot.peripheral.NoRouteException;
import com.sun.spot.peripheral.Spot;
import com.sun.spot.peripheral.radio.IRadioPolicyManager;
import com.sun.spot.peripheral.radio.routing.RouteInfo;
import com.sun.spot.resources.Resources;
import com.sun.spot.resources.transducers.IAccelerometer3D;
import com.sun.spot.resources.transducers.IMeasurementRange;
import com.sun.spot.resources.transducers.ITriColorLED;
import com.sun.spot.service.ISpotRadioHelper;
import com.sun.spot.service.ServiceRegistry;
import com.sun.spot.util.IEEEAddress;
import com.sun.spot.util.Utils;
import java.io.IOException;
import java.util.Vector;
import javax.microedition.io.Connector;
import javax.microedition.io.Datagram;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;


public class SensorSampler extends MIDlet implements Constants, Constants_Tipo {

    private static IAccelerometer3D accel;
    private static ITriColorLED led1, led2, led3, led4;
    private static ITriColorLED led5, led6, led7, led8;
    private RadiogramConnection txConn = null;  // conexi�n para enviar hacia la BS
    private Datagram txDg;                      // datagrama para enviar hacia la BS
    private boolean continua = false;
    private boolean sendData = false;
    private boolean sendAll = false;
    private boolean connected = false;
    private final Object SemaforoSendData = new Object();
    private Vector vectPk = new Vector(5);       // vector de PacketType
    private String BSAddress = null;
    private boolean threadStarted = false;
    private ISpotRadioHelper radioHelper;

    protected void startApp() throws MIDletStateChangeException {

        // Set transmission properties
        IRadioPolicyManager rpm = Spot.getInstance().getRadioPolicyManager();

        if (TIPO_APP.equalsIgnoreCase(TIPO_C)) {
            rpm.setChannelNumber(SPOT_CHANNEL_C);
            rpm.setPanId(SPOT_PANID_C);
        } else {
            rpm.setChannelNumber(SPOT_CHANNEL_P);
            rpm.setPanId(SPOT_PANID_P);
        }
        rpm.setOutputPower(SPOT_POWER);
        System.out.println("channel: " + rpm.getChannelNumber());
        System.out.println("PAN: " + rpm.getPanId());
        System.out.println("power: " + rpm.getOutputPower());

        System.out.println("SAMPLE_PERIOD: " + SAMPLE_PERIOD);
        
        radioHelper = (ISpotRadioHelper)ServiceRegistry.getInstance().lookup(ISpotRadioHelper.class);

        

        // Get the LEDs
        led1 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED1");
        led2 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED2");
        led3 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED3");
        led4 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED4");

        led5 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED5");
        led6 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED6");
        led7 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED7");
        led8 = (ITriColorLED) Resources.lookup(ITriColorLED.class, "LED8");

        led1.setRGB(255, 0, 0);
        led1.setOn();

        switch (SAMPLE_PERIOD) {
            case 10:
                led4.setRGB(255, 0, 0);
                break;
            case 20:
                led4.setRGB(0, 255, 0);
                break;
            case 40:
                led4.setRGB(0, 0, 255);
                break;
            default:
                led4.setRGB(255, 255, 255);
                break;
        }

        led4.setOn();

        String ourAddress = System.getProperty("IEEE_ADDRESS");

        // Get the accelerometer and set the proper scale 
        accel = (IAccelerometer3D) Resources.lookup(IAccelerometer3D.class);
        IMeasurementRange macc = (IMeasurementRange) accel;
        macc.setCurrentRange(macc.getNumberRanges() - 1);
        System.out.println("Accelerometer now using the " + macc.getMaxValue() + " g scale");


        led3.setRGB(255, 0, 0);
        led3.setOn(); 

        System.out.println("Starting sensor sampler application on " + ourAddress + " ...");

        // Listen for downloads/commands over USB connection
        new com.sun.spot.service.BootloaderListenerService().getInstance().start();

        //startTransmitterThread();
        startReceiverThread();

        led1.setRGB(0, 255, 0);
        led1.setOn();   


        continua = true;
        sendAccData();
        led1.setRGB(255, 0, 0);
        led1.setOn();
    }

    protected void pauseApp() {
        // This will never be called by the Squawk VM
    }

    protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
        // Only called if startApp throws any exception other than MIDletStateChangeException
    }

    public static double[] getSensorData() {
        double[] reading = new double[NUM_MEASURES];
        try {
            reading = accel.getAccelValues();

        } catch (IOException ex) {
            ex.printStackTrace();
            led5.setRGB(255, 0, 0);
            led5.setOn();
        }
        return reading;
    }

    private void sendAccData() {
        while (continua) {

            long now = System.currentTimeMillis();
            boolean sendData_aux = false;
            synchronized (SemaforoSendData) {
                sendData_aux = sendData;
            }
            if (sendData_aux) {
                led2.setRGB(0, 255, 0);
                led2.setOn();
                double[] reading = getSensorData();
                synchronized (vectPk) {
                    vectPk.addElement(new PacketType(now, reading));
                }
                System.out.println(now + " size: " + vectPk.size());
                if (vectPk.size() > 10000){
                    led5.setRGB(0, 255, 0);
                    led5.setOn();
                }
                
                if (vectPk.size() > 15000){
                    led5.setRGB(0, 0, 255);
                    led5.setOn();
                }

            } else {
                led2.setRGB(255, 0, 0);
                led2.setOn();
            }

            // Go to sleep to conserve battery
            if (SAMPLE_PERIOD - (System.currentTimeMillis() - now) > 0) {         
                Utils.sleep(SAMPLE_PERIOD - (System.currentTimeMillis() - now));
            } else {
                System.out.println("------------------ " + (SAMPLE_PERIOD - (System.currentTimeMillis() - now)));
            }
        }
    }


    synchronized public void startReceiverThread() {
        new Thread() {

            public void run() {
                RadiogramConnection rxConn = null;
                Datagram rxDg = null;

                try {
                    rxConn = (RadiogramConnection) Connector.open("radiogram://:" + BROADCAST_PORT);
                    rxDg = rxConn.newDatagram(rxConn.getMaximumLength());
                } catch (IOException e) {
                    System.out.println("Could not open radiogram receiver connection");
                    e.printStackTrace();

                    led8.setRGB(255, 0, 0);
                    led8.setOn();
                    return;
                }
                while (continua) {
                    try {
                        rxDg.reset();
                        rxConn.receive(rxDg);
                        byte packetType = rxDg.readByte();
                        BSAddress = rxDg.getAddress();
                        System.out.println("BSAddres: " + BSAddress);

                        switch (packetType) {
                            case START_DATA_FLOW:
                                System.out.println("<startReceiverThread>: start tx");
                                led5.setOff();
                                led6.setOff();
                                led7.setOff();
                                led8.setOff();
                                synchronized (SemaforoSendData) {
                                    sendData = true;
                                }
                                if (BSAddress != null & !threadStarted) {
                                    System.out.println("<startReceiverThread>: start tx thread");
                                    startTransmitterThread();
                                }
                                break;
                            case STOP_DATA_FLOW:
                                System.out.println("<startReceiverThread>: stop tx");
                                synchronized (SemaforoSendData) {
                                    sendData = false;
                                    sendAll = true;
                                }
                                break;
                            case DISPLAY_SERVER_QUITTING:
                                continua = false;
                                break;
                            case CALIB_SENS:
                                led3.setRGB(0, 255, 0);
                                led3.setOn();
                        }
                    } catch (IOException e) {
                        System.out.println("nothing received");
                        led7.setRGB(255, 0, 0);
                        led7.setOn();
                    }
                }
                led3.setRGB(0, 0, 255);
                led3.setOn();
            }
        }.start();
    }

    synchronized public void startTransmitterThread() {
        new Thread() {

            public void run() {
                try {
                    // Open up a broadcast connection to the host port
                    // where the 'on Desktop' portion of this demo is listening
                    System.out.println("<startTransmitterThread>: new thread");
                    txConn = (RadiogramConnection) Connector.open("radiogram://" + BSAddress + ":" + HOST_PORT);
                    txDg = txConn.newDatagram(100);  // only sending 32 bytes of data
                    System.out.println("<startTransmitterThread>: connection ok with bs: " + BSAddress);
                    threadStarted = true;
                } catch (Exception e) {
                    led8.setRGB(0, 0, 255);
                    led8.setOn();
                    System.err.println("Caught " + e + " in connection initialization.");
                    notifyDestroyed();
                }
                while (continua) {
                    
                    if (sendAll & vectPk.isEmpty()){
                            sendAll = false;
                        }

                    if ((vectPk.size() >= NUM_MEASURES) | (sendAll)) {

                        // Package the time and sensor reading into a radio datagram and send it.
                        txDg.reset();
                        
                        int max_tx = vectPk.size();
                        if (NUM_MEASURES < max_tx) max_tx = NUM_MEASURES;

                        for (int k = 0; k < max_tx; k++) {
                            PacketType pk = (PacketType) vectPk.firstElement();

                            synchronized (vectPk) {
                                vectPk.removeElement(pk);
                            }
                            
                            try {      
                                txDg.writeLong(pk.getTimeStamp());
                                for (int i = 0; i < pk.getReadingSize(); i++) {
                                    txDg.writeFloat(pk.getReading(i));
                                }
                            } catch (IOException e) {
                                System.err.println("Caught " + e + " while sending sensor sample.");
                                e.printStackTrace();

                                led6.setRGB(0, 0, 255);
                                led6.setOn();
                            }
                        }
                        long now = System.currentTimeMillis();
                        try {          
                            txConn.send(txDg);
                            
                            RouteInfo[] ri = radioHelper.getRouteInfo(IEEEAddress.toLong(BSAddress));
                            System.out.println(ri.length);
                            if (ri.length>0){
                                System.out.println(ri[0].toString() + "-------" + ri[0].hopCount);
                                if (ri[0].hopCount>1){
                                    led7.setRGB(0, 255, 0);
                                    led7.setOn();
                                }
                            }
                        } catch (NoRouteException e) {
                            led6.setRGB(0, 255, 0);
                            led6.setOn();
                        } catch (Exception e) {
                            System.err.println("Caught " + e + " while sending sensor sample.");
                            e.printStackTrace();

                            led6.setRGB(255, 0, 0);
                            led6.setOn();
                        }
                        
                    } else {
                        if (!sendAll){
                            Utils.sleep(2 * SAMPLE_PERIOD);
                        }
                    }
                }

            }
        }.start();
    }


}
