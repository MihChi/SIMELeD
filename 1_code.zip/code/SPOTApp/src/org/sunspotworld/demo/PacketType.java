package org.sunspotworld.demo;
/**
 *
 * @author mihaela.chidean@urjc.es
 */
public class PacketType {
    
    private long timeStamp;
    private float[] accData;
    
    
    public PacketType(long t, double[] r){
        accData = new float[r.length];
        
        timeStamp = t;
        for(int i = 0; i < r.length; i++){
            accData[i] = (float) r[i];
        }
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public int getReadingSize() {
        return accData.length;
    }

    public float getReading(int i) {
        return accData[i];
    }
}
